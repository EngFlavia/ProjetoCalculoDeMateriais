/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.interfaces;

import java.sql.ResultSet;
import java.util.ArrayList;
import models.Usuario;

/**
 *
 * @author Moreno
 */
public interface IUsuarioDAO {
    public void inserir(Usuario usuario);
    public void editar(Usuario usuario);
    public void excluir(int codigo);
    public ArrayList<Usuario> selecionar();
    public Usuario selecionarPorCodigo(int codigo);
    public ResultSet selecionarTabela();
    public boolean autenticar(String usuario, String senha);
}
